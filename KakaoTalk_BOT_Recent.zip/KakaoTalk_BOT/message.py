import time
import win32con 
import win32api
import win32gui
import pyautogui
import pyperclip
import csv
import os
from datetime import datetime
import uuid

class KakaoChatConfig:
    def __init__(self):
        self.chat_messages = {
        }

class KakaoChatService:
    def __init__(self):
        self.start_time = datetime.now()
        self.start_time_str = self.start_time.strftime('%Y%m%d_%H%M')

    def kakao_sendtext_and_close(self, chatroom_name, text):
        hwndMain = self.open_chatroom(chatroom_name)
        if hwndMain != 0:
            win32gui.SetForegroundWindow(hwndMain)
            time.sleep(0.1)

            actual_title = win32gui.GetWindowText(hwndMain)

            if chatroom_name not in actual_title:
                self.log_case(chatroom_name, actual_title, text, code, searchedroom_name, "opened_wrong_chatroom", "") 
                win32gui.PostMessage(hwndMain, win32con.WM_CLOSE, 0, 0)

            else:
                try:
                    # Send the message
                    code = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    pyperclip.copy(f"{code}" + "\n\n" + text)
                    pyautogui.hotkey('ctrl', 'v')
                    time.sleep(0.5)
                    
                    pyautogui.press('enter')
                    time.sleep(1)

                    # Unique code confirmation
                    new_hwnd, searchedroom_name = self.unique_code_confirm(code, hwndMain)
            
                    # Check if the message actually sent
                    if searchedroom_name == chatroom_name:
                        self.log_case(chatroom_name, actual_title, text, code, searchedroom_name, "message_sent_desired_chatroom", "")
                        
                    else:
                        if searchedroom_name == "Integrated Search":
                            new_hwnd, searchedroom_name = self.unique_code_confirm(code, hwndMain)
                            if searchedroom_name == chatroom_name:
                                self.log_case(chatroom_name, actual_title, text, code, searchedroom_name, "message_sent_desired_chatroom", "")
                        else:
                            self.log_case(chatroom_name, actual_title, text, code, searchedroom_name, "message_sent_wrong_chatroom", "")

                except Exception as e:
                    self.log_case(chatroom_name, actual_title, text, code, searchedroom_name, "N/A", e)

                hwndMain = new_hwnd
                win32gui.PostMessage(hwndMain, win32con.WM_CLOSE, 0, 0)
                time.sleep(1)
                
                integrated_hwnd = win32gui.GetForegroundWindow()
                integrated_window = win32gui.GetWindowText(integrated_hwnd)
                if integrated_window == "Integrated Search":
                    win32gui.PostMessage(integrated_hwnd, win32con.WM_CLOSE, 0, 0)

        else:
            self.log_case(chatroom_name, "", text, "", "", "chatroom_not_found", "")

    # Enter for open_chatroom
    def SendReturn(sefl, hwnd):
        win32api.PostMessage(hwnd, win32con.WM_KEYDOWN, win32con.VK_RETURN, 0) # Press key
        time.sleep(0.01)
        win32api.PostMessage(hwnd, win32con.WM_KEYUP, win32con.VK_RETURN, 0) # Unpress key

    def open_chatroom(self, chatroom_name):

        hwndkakao = win32gui.FindWindow(None, "KakaoTalk")
        hwndkakao_edit1 = win32gui.FindWindowEx( hwndkakao, None, "EVA_ChildWindow", None)
        hwndkakao_edit2_1 = win32gui.FindWindowEx( hwndkakao_edit1, None, "EVA_Window", None)
        hwndkakao_edit2_2 = win32gui.FindWindowEx( hwndkakao_edit1, hwndkakao_edit2_1, "EVA_Window", None)
        hwndkakao_edit3 = win32gui.FindWindowEx( hwndkakao_edit2_2, None, "Edit", None)

        # Search for chatroom
        win32api.SendMessage(hwndkakao_edit3, win32con.WM_SETTEXT, 0, chatroom_name)
        time.sleep(1) 
        self.SendReturn(hwndkakao_edit3)

        # Clear the search box
        time.sleep(1)
        win32api.SendMessage(hwndkakao_edit3, win32con.WM_SETTEXT, 0, "")
        time.sleep(1)

        hwndMain = win32gui.FindWindow(None, chatroom_name)

        return hwndMain
    
    def unique_code_confirm(self, code, hwndMain):
        pyautogui.keyDown('ctrl')
        pyautogui.press('f')
        time.sleep(0.5)
        pyperclip.copy(code)
        pyautogui.hotkey('ctrl', 'v')
        pyautogui.press('tab')   
        pyautogui.press('space')
        time.sleep(0.5)    
        win32gui.PostMessage(hwndMain, win32con.WM_CLOSE, 0, 0)
        pyautogui.press('enter')
        time.sleep(0.2)
        pyautogui.press('down')
        time.sleep(0.2)
        pyautogui.press('enter')
        time.sleep(0.5)
        new_hwnd = win32gui.GetForegroundWindow()
        searchedroom_name = win32gui.GetWindowText(new_hwnd)
        time.sleep(0.5)

        return new_hwnd, searchedroom_name
    
    def log_case(self, chatroom_desired, chatroom_opened, message_input, unique_code_search, chatroom_found, case, e):
        match case:
            case "opened_wrong_chatroom":
                self.log_result(chatroom_desired, chatroom_opened, message_input, "", "FAIL", "Opend Wrong Chatroom: Message Not Sent")
                print (False, chatroom_desired, message_input)
                self.last_log_case_result = (False, chatroom_desired, message_input)
                return (False, chatroom_desired, message_input)
            case "chatroom_not_found":
                self.log_result(chatroom_desired, "", message_input, "", "FAIL", "Chatroom Not Found: Message Not Sent")
                print (False, chatroom_desired, message_input)
                self.last_log_case_result = (False, chatroom_desired, message_input)
                return (False, chatroom_desired, message_input)
            case "message_sent_desired_chatroom":
                self.log_result(chatroom_desired, chatroom_opened, message_input, unique_code_search, chatroom_found, "SUCCESS")
                print (True, chatroom_desired, message_input)
                self.last_log_case_result = (True, chatroom_desired, message_input)
                return (True, chatroom_desired, message_input)
            case "message_sent_wrong_chatroom":
                self.log_result(chatroom_desired, chatroom_opened, message_input, unique_code_search, chatroom_found, "FAIL", "Message Sent to Wrong Chatroom")
                print (False, chatroom_desired, message_input)
                self.last_log_case_result = (False, chatroom_desired, message_input)
                return (False, chatroom_desired, message_input)
            case "N/A":
                self.log_result(chatroom_desired, chatroom_opened, message_input, "", "", "FAIL", f"{str(e)}: Message Not Sent")
                print (False, chatroom_desired, message_input)
                self.last_log_case_result = (False, chatroom_desired, message_input)
                return (False, chatroom_desired, message_input)
            
    def log_result(self, chatroom_desired, chatroom_opened, message_input, unique_code_search, chatroom_found, status, reason_fail = ""):
        now = datetime.now()

        year = self.start_time.strftime('%Y')
        month = self.start_time.strftime('%m')
        day = self.start_time.strftime('%d')
        hour = self.start_time.strftime('%H')

        base_dir = r"C:\Users\CMIA41AS0001\LGVISION\Log"
        folder_path = os.path.join(base_dir, year, month, day, hour)
        os.makedirs(folder_path, exist_ok=True)

        filename = f'kakao_log_{self.start_time_str}.csv'
        file_path = os.path.join(folder_path, filename)

        write_header = not os.path.exists(file_path)
        
        with open(file_path, "a", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            if write_header:
                writer.writerow([
                    "Time", "Chatroom(Desired)", "Chatroom(Opened)",
                    "Message Input", "Unique Code(Searched)", "Chatroom(Found)", "Status", "Reason(FAIL)"
                ])
            writer.writerow([
                now.strftime("%Y-%m-%d %H:%M:%S"),
                chatroom_desired,
                chatroom_opened,
                message_input,
                unique_code_search,
                chatroom_found,
                status,
                reason_fail
            ])

class KakaoBot:
    '''
    KakaoBot class to manage sending messages in KakaoTalk chatrooms.
    It uses KakaoChatConfig for configuration and KakaoChatService for sending messages.
    It can send messages to all chatrooms defined in the configuration or to a specific chatroom.
    '''
    def __init__(self, config: KakaoChatConfig, service: KakaoChatService):
        self.config = config
        self.service = service
    
    def send_all(self):
        '''
        Send all messages in the config to their respective chatrooms.
        '''
        for chatroom, message in self.config.chat_messages.items():
            self.service.kakao_sendtext_and_close(chatroom, message)
    
    def send_one(self, chatroom, message):
        '''
        Send a message to a specific chatroom.
        If the chatroom is not found, it will not send the message and return False.
        '''
        self.service.kakao_sendtext_and_close(chatroom, message)
    
    def update_message(self, chatroom, message):
        '''
        Update the message for a specific chatroom if needed.
        '''
        self.config.chat_messages[chatroom] = message

def main():
    config = KakaoChatConfig()
    service = KakaoChatService()
    bot = KakaoBot(config, service)
    
    reciever = "김지희 (Jihee Kim)"
    text = "21세기의 문턱을 넘어서면서 인류는 전례 없는 속도로 진화하는 과학기술의 흐름 속에 놓이게 되었고, 특히 인공지능, 빅데이터, 사물인터넷, 양자 컴퓨팅 등 첨단 정보기술의 급속한 발전은 산업 구조뿐만 아니라 인간의 사고방식, 교육 방식, 심지어는 일상생활의 사소한 부분에까지 광범위하고도 심층적인 변화를 일으키고 있으며, 이로 인해 우리는 전통적인 가치관과 패러다임에 대한 재고가 불가피한 상황에 직면하고 있습니다. 예를 들어, 과거에는 사람 간의 대면 소통이 인간 관계의 중심이었으나, 현재는 메신저 앱과 SNS가 소통의 중심축을 이루며, 디지털 정체성과 현실 정체성의 경계가 점점 모호해지는 상황 속에서 개인은 끊임없는 정보의 홍수와 주체적 사고 사이에서 균형을 잡아야만 하며, 이는 디지털 시대를 살아가는 모든 이들이 직면한 보편적인 과제가 되었습니다. 또한 기계가 인간의 판단을 대체하고, 알고리즘이 삶의 선택을 예측하는 시대에 인간의 역할은 점점 축소되는 것이 아닌가 하는 철학적 우려 또한 제기되고 있으며, 이러한 고민은 단순히 기술의 효율성이나 생산성에 국한된 문제가 아니라 인류의 존엄성, 자유의지, 그리고 공동체적 윤리와 직결된 중대한 문제이기 때문에, 우리는 기술의 진보를 무조건적으로 환영하거나 거부하기보다는 그것이 궁극적으로 인간의 삶을 어떻게 변화시키고, 그 변화가 과연 바람직한 방향인지를 진지하게 고찰하고 사회적 합의를 도출해나가는 과정이 절실히 요구됩니다. 나아가, 이러한 변화의 중심에서 교육은 단순한 지식 전달이 아닌 비판적 사고와 창의력, 그리고 윤리적 감수성을 길러주는 방향으로 재편되어야 하며, 정책 입안자들은 기술의 발전이 가져오는 사회적 양극화, 정보 격차, 프라이버시 침해 문제에 적극 대응할 수 있는 제도적 장치를 마련함으로써 모두가 디지털 혁신의 수혜자가 될 수 있도록 포용적인 시스템을 구축해야 할 것입니다."
    bot.update_message(reciever, text)
    kakao_opentalk_names = ["김지희 (Jihee Kim)", "NND alert test 1", "NND alert test 2", "NND alert test 3", "test 4", "test 5", "test 6", "test 7", "test 8", "test 9", "test 10"]

    message = "MI2 NND(A) #02 INTEGRATION LOT_ID: 8EGB35NA02 has NG Rate of 7.33% at 2025-07-11 08:01:21. Total defect count is 47. Surface defect count: 36, Dimension defect count: 15. Please Check!!"

    # for i in range(100):
    #     selected_room = random.choice(kakao_opentalk_names)
    #     print(f"[{i+1}/100] Sending to: {selected_room}")
    #     bot.send_one(selected_room, message)
    #     time.sleep(0.5)

    bot.send_all()


if __name__ == "__main__":
    main()
